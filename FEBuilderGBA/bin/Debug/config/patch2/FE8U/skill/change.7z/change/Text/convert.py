#!/usr/bin/python
# coding: UTF-8
import os
import shutil

f = open('Text Definitions.event')
lines2 = f.readlines() # 1行毎にファイル終端まで全て読む(改行文字も含まれる)
f.close()

# lines2: リスト。要素は1行の文字列データ
starid=0xE00
newid=starid
for line in lines2:
	if (line.find("#define") == -1):
		continue
	s=line.find("0x",10)
	if (s == -1):
		continue

	oldid=line[s:].strip()
	newline = line[0:s] + " " + hex(newid) + " //" + oldid
#	print(newline)
	
	srcfile="_textentries/"+oldid+".txt"
	destfile="_textentries/"+hex(newid)+".txt"
#	shutil.copyfile(srcfile,destfile)
	
	febuildergba_patch="TEXTADV:" + hex(newid) + "=" + hex(newid) + ".txt"
	print(febuildergba_patch)
	newid = newid + 1

